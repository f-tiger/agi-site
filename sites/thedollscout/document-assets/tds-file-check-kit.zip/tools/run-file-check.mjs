import {fileURLToPath} from 'node:url';
import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const reference=readFileSync(new URL('../delivery/reference.txt',import.meta.url),'utf8').trim();
const result=spawnSync(process.execPath,[fileURLToPath(new URL('./verify-file-cli.mjs',import.meta.url)),fileURLToPath(new URL('../delivery/asset.bin',import.meta.url)),reference],{stdio:'inherit',shell:false});
if(result.error)console.error('Could not start the local verifier.');
process.exitCode=result.status??2;
